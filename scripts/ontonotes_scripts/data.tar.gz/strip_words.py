import sys
with open('tmp.conll', 'w') as fout:
  for line in sys.stdin:
    fields = line.strip().split('\t')
    if len(fields) < 10:
      fout.write(line)
    else:
      fields[1] = '-'
      fields[2] = '-'
      fields[13] = '-'
      fout.write('\t'.join(fields) + '\n')
